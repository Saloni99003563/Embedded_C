/*
 * 003LedExt.c
 *
 * Created on: 22-Feb-2021
 * Author: Training
 *
 */
#include "stm32f4xx.h"

#include "gpio_driver.h"

#define HIGH 		1
#define BTN_PRESSED HIGH

void set_rgb(uint8_t red, uint8_t green, uint8_t blue)
{

}

void delay(void)
{
	for(uint32_t i=0;i<500000;i++)
	{

	}
}

int main(void)
{
	/*
	 * RGB Led
	 */
	GPIO_Handle_t GpioLedR, GpioLedG, GpioLedB, GpioIOBtn;

	// Led R
	GpioLedR.pGPIOx= GPIOD;
	GpioLedR.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_2;
	GpioLedR.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLedR.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_HIGH;
	GpioLedR.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLedR);

	// Led G
	GpioLedG.pGPIOx= GPIOD;
	GpioLedG.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_4;
	GpioLedG.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLedG.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_HIGH;
	GpioLedG.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLedG);

	// Led B
	GpioLedB.pGPIOx= GPIOD;
	GpioLedB.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_6;
	GpioLedB.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLedB.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_HIGH;
	GpioLedB.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_Init(&GpioLedB);

	// Button
	GpioIOBtn.pGPIOx= GPIOA;
	GpioIOBtn.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	GpioIOBtn.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_IN;
	GpioIOBtn.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_HIGH;
	GpioIOBtn.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;

	GPIO_PeriClockControl(GPIOA, ENABLE);
	GPIO_Init(&GpioIOBtn);

	while(1)
	{
		if (GPIO_ReadFromInputPin(GPIOA, GPIO_PIN_NO_0) == BTN_PRESSED)
		{
			GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NO_2);
			delay();
		}
	}
	return(0);
}
