/*
 * GPIO_DRIVER.H
 *
 * created on: Feb 20 ,2021
 *  Author: 40010750
 */

#ifndef _GPIO_DRIVER_H
#define _GPIO_DRIVER_H

#include "stm32f4xx.h"

typedef struct
{
	uint8_t GPIO_PinNumber;
	uint8_t GPIO_PinMode;
	uint8_t GPIO_PinSpeed;
	uint8_t GPIO_PinPuPdControl;
	uint8_t GPIO_PinOPType;
	uint8_t GPIO_PinAltFuncMode;
} GPIO_Pinconfig_t;




typedef struct
{
	Gpio_RegDef_t *pGPIOx;
	GPIO_Pinconfig_t GPIO_PinConfig;

}GPIO_Handle_t;

// PIN NUMBERS
#define GPIO_PIN_NO_0   0
#define GPIO_PIN_NO_1   1
#define GPIO_PIN_NO_2   2
#define GPIO_PIN_NO_3   3
#define GPIO_PIN_NO_4   4
#define GPIO_PIN_NO_5   5
#define GPIO_PIN_NO_6   6
#define GPIO_PIN_NO_7   7
#define GPIO_PIN_NO_8   8
#define GPIO_PIN_NO_9   9
#define GPIO_PIN_NO_10  10
#define GPIO_PIN_NO_11  11
#define GPIO_PIN_NO_12  12
#define GPIO_PIN_NO_13  13
#define GPIO_PIN_NO_14  14
#define GPIO_PIN_NO_15  15


//MODES OF GPIO'S

#define GPIO_MODE_IN         0
#define GPIO_MODE_OUT        1
#define GPIO_MODE_ALT_FUNC   2
#define GPIO_MODE_ANALOG     3

//OUTPUT TYPE
#define GPIO_OP_TYPE_PP   0
#define GPIO_OP_TYPE_OD   1


//SPEED OG GPIO

#define GPIO_SPEED_LOW         0
#define GPIO_SPEED_MEDIUM      1
#define GPIO_SPEED_HIGH        2
#define GPIO_SPEED_VERY_HIGH   3

//GPIO PIN FOR PULL UP AND AND PULL DOWN

#define GPIO_NO_PUPD      0
#define GPIO_NO_PU        1
#define GPIO_NO_PD        2






/*
 * To control clock setting
 */

void GPIO_PeriClockControl(Gpio_RegDef_t *pGPIOx, uint8_t EnorDi);
/*
 *  To do
 */
void GPIO_Init(GPIO_Handle_t *pGPIOHandle);
void GPIO_DeInit(Gpio_RegDef_t *pGPIOx);
/*
 *
 */
uint8_t GPIO_ReadFromInputPin(Gpio_RegDef_t *pGPIOx, uint8_t PinNumber);
uint16_t GPIO_ReadFromInputPort(Gpio_RegDef_t *pGPIOx);
/*
 *
 */
void GPIO_WriteToOutputPin(Gpio_RegDef_t *pGPIOx,uint8_t PinNumber,uint8_t value);
void GPIO_WriteToOutputPort(Gpio_RegDef_t *pGPIOx,uint16_t value);
/*
 * TO DO
 */
void GPIO_ToggleOutputPin(Gpio_RegDef_t *pGPIOx,uint8_t PinNumber);


#endif
